import { Request, Response } from 'express';
import Ticket from '../models/Ticket';

// GET /tickets - List all tickets
export const getTickets = async (req: Request, res: Response): Promise<void> => {
  try {
    const tickets = await Ticket.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: tickets.length, data: tickets });
  } catch (error: any) {
    res.status(500).json({ success: false, message: 'Server error while fetching tickets', error: error.message });
  }
};

// POST /tickets - Create a ticket
export const createTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const { subject, description, priority, status } = req.body;

    // Validate required fields
    if (!subject || !description || !priority) {
      res.status(400).json({ success: false, message: 'Subject, description, and priority are required' });
      return;
    }

    const validPriorities = ['Low', 'Medium', 'High'];
    const validStatuses = ['Open', 'In Progress', 'Closed'];

    if (!validPriorities.includes(priority)) {
      res.status(400).json({ success: false, message: 'Priority must be Low, Medium, or High' });
      return;
    }

    if (status && !validStatuses.includes(status)) {
      res.status(400).json({ success: false, message: 'Status must be Open, In Progress, or Closed' });
      return;
    }

    const ticket = await Ticket.create({ subject, description, priority, status: status || 'Open' });
    res.status(201).json({ success: true, message: 'Ticket created successfully', data: ticket });
  } catch (error: any) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e: any) => e.message);
      res.status(400).json({ success: false, message: messages.join(', ') });
    } else {
      res.status(500).json({ success: false, message: 'Server error while creating ticket', error: error.message });
    }
  }
};

// DELETE /tickets/:id - Delete a single ticket
export const deleteTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const ticket = await Ticket.findByIdAndDelete(req.params.id);
    if (!ticket) {
      res.status(404).json({ success: false, message: 'Ticket not found' });
      return;
    }
    res.status(200).json({ success: true, message: 'Ticket deleted successfully' });
  } catch (error: any) {
    if (error.name === 'CastError') {
      res.status(400).json({ success: false, message: 'Invalid ticket ID format' });
    } else {
      res.status(500).json({ success: false, message: 'Server error while deleting ticket', error: error.message });
    }
  }
};

// DELETE /tickets - Clear ALL tickets (Group 12 Feature)
export const clearAllTickets = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await Ticket.deleteMany({});
    res.status(200).json({
      success: true,
      message: `All tickets cleared successfully. ${result.deletedCount} ticket(s) deleted.`,
      deletedCount: result.deletedCount,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: 'Server error while clearing tickets', error: error.message });
  }
};
