import mongoose, { Document, Schema } from 'mongoose';

export interface ITicket extends Document {
  subject: string;
  description: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Open' | 'In Progress' | 'Closed';
  createdAt: Date;
}

const TicketSchema: Schema = new Schema(
  {
    subject: {
      type: String,
      required: [true, 'Subject is required'],
      trim: true,
      minlength: [3, 'Subject must be at least 3 characters'],
      maxlength: [100, 'Subject cannot exceed 100 characters'],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      minlength: [10, 'Description must be at least 10 characters'],
    },
    priority: {
      type: String,
      enum: {
        values: ['Low', 'Medium', 'High'],
        message: 'Priority must be Low, Medium, or High',
      },
      required: [true, 'Priority is required'],
    },
    status: {
      type: String,
      enum: {
        values: ['Open', 'In Progress', 'Closed'],
        message: 'Status must be Open, In Progress, or Closed',
      },
      default: 'Open',
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model<ITicket>('Ticket', TicketSchema);
