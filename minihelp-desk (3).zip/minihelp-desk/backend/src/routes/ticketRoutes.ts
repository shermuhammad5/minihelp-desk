import { Router } from 'express';
import {
  getTickets,
  createTicket,
  deleteTicket,
  clearAllTickets,
} from '../controllers/ticketController';

const router = Router();

// GET /tickets - list all
router.get('/', getTickets);

// POST /tickets - create one
router.post('/', createTicket);

// DELETE /tickets - clear ALL (must be before /:id)
router.delete('/', clearAllTickets);

// DELETE /tickets/:id - delete one
router.delete('/:id', deleteTicket);

export default router;
