import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import TicketsPage from './pages/TicketsPage';
import NotFoundPage from './pages/NotFoundPage';
import './index.css';

function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1a1e2a',
            color: '#e8eaf0',
            border: '1px solid #2f3347',
            fontFamily: 'Syne, sans-serif',
            fontSize: '0.88rem',
          },
          success: { iconTheme: { primary: '#34d399', secondary: '#0d0f14' } },
          error: { iconTheme: { primary: '#f05252', secondary: '#0d0f14' } },
        }}
      />
      <Routes>
        <Route path="/" element={<TicketsPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
