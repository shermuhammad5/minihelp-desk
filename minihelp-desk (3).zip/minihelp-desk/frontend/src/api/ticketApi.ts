import axios from 'axios';
import type { Ticket, ApiResponse } from '../types/ticket';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

export const ticketApi = {
  getAll: async (): Promise<ApiResponse<Ticket[]>> => {
    const res = await api.get('/tickets');
    return res.data;
  },

  create: async (data: Omit<Ticket, '_id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Ticket>> => {
    const res = await api.post('/tickets', data);
    return res.data;
  },

  deleteOne: async (id: string): Promise<ApiResponse<null>> => {
    const res = await api.delete(`/tickets/${id}`);
    return res.data;
  },

  clearAll: async (): Promise<ApiResponse<null>> => {
    const res = await api.delete('/tickets');
    return res.data;
  },
};
