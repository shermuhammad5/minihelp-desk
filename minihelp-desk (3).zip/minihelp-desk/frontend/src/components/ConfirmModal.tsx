import React from 'react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  danger?: boolean;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = 'Confirm',
  onConfirm,
  onCancel,
  danger = false,
}) => {
  if (!isOpen) return null;

  return (
    <div style={styles.overlay} onClick={onCancel}>
      <div style={styles.modal} onClick={e => e.stopPropagation()}>
        <div style={styles.iconWrap}>
          <span style={styles.icon}>⚠️</span>
        </div>
        <h2 style={styles.title}>{title}</h2>
        <p style={styles.message}>{message}</p>
        <div style={styles.actions}>
          <button onClick={onCancel} style={styles.cancelBtn}>
            Cancel
          </button>
          <button
            onClick={onConfirm}
            style={{ ...styles.confirmBtn, ...(danger ? styles.dangerBtn : {}) }}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  overlay: {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.7)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    animation: 'fadeIn 0.15s ease',
    padding: '1rem',
  },
  modal: {
    background: 'var(--surface)',
    border: '1px solid var(--border-light)',
    borderRadius: 'var(--radius)',
    padding: '2rem',
    width: '100%',
    maxWidth: 380,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '0.75rem',
    textAlign: 'center',
    boxShadow: 'var(--shadow)',
    animation: 'fadeInUp 0.2s ease',
  },
  iconWrap: {
    width: 56,
    height: 56,
    background: 'var(--red-dim)',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '1.5rem',
    marginBottom: '0.25rem',
  },
  icon: { fontSize: '1.6rem' },
  title: {
    fontSize: '1.1rem',
    fontWeight: 800,
    color: 'var(--text)',
  },
  message: {
    fontSize: '0.88rem',
    color: 'var(--text-dim)',
    lineHeight: 1.6,
    marginBottom: '0.5rem',
  },
  actions: {
    display: 'flex',
    gap: '0.75rem',
    width: '100%',
  },
  cancelBtn: {
    flex: 1,
    padding: '0.65rem',
    background: 'var(--surface2)',
    border: '1px solid var(--border-light)',
    borderRadius: 'var(--radius-sm)',
    color: 'var(--text)',
    fontFamily: 'Syne, sans-serif',
    fontWeight: 600,
    fontSize: '0.9rem',
    cursor: 'pointer',
  },
  confirmBtn: {
    flex: 1,
    padding: '0.65rem',
    background: 'var(--accent)',
    border: 'none',
    borderRadius: 'var(--radius-sm)',
    color: '#fff',
    fontFamily: 'Syne, sans-serif',
    fontWeight: 700,
    fontSize: '0.9rem',
    cursor: 'pointer',
  },
  dangerBtn: {
    background: 'var(--red)',
  },
};

export default ConfirmModal;
