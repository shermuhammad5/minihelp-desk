import React from 'react';
import type { Ticket } from '../types/ticket';

interface TicketCardProps {
  ticket: Ticket;
  onDelete: (id: string) => void;
}

const priorityColors: Record<string, { bg: string; text: string; dot: string }> = {
  High: { bg: 'var(--red-dim)', text: 'var(--red)', dot: 'var(--red)' },
  Medium: { bg: 'var(--yellow-dim)', text: 'var(--yellow)', dot: 'var(--yellow)' },
  Low: { bg: 'var(--green-dim)', text: 'var(--green)', dot: 'var(--green)' },
};

const statusColors: Record<string, { bg: string; text: string }> = {
  Open: { bg: 'var(--accent-dim)', text: 'var(--accent)' },
  'In Progress': { bg: 'var(--orange-dim)', text: 'var(--orange)' },
  Closed: { bg: 'rgba(107,114,128,0.15)', text: 'var(--text-muted)' },
};

const TicketCard: React.FC<TicketCardProps> = ({ ticket, onDelete }) => {
  const priority = priorityColors[ticket.priority] || priorityColors.Low;
  const status = statusColors[ticket.status] || statusColors.Open;
  const date = new Date(ticket.createdAt).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });

  return (
    <div style={styles.card}>
      <div style={styles.cardTop}>
        <div style={styles.badges}>
          <span style={{ ...styles.badge, background: priority.bg, color: priority.text }}>
            <span style={{ ...styles.dot, background: priority.dot }} />
            {ticket.priority}
          </span>
          <span style={{ ...styles.badge, background: status.bg, color: status.text }}>
            {ticket.status}
          </span>
        </div>
        <button
          onClick={() => onDelete(ticket._id)}
          style={styles.deleteBtn}
          title="Delete ticket"
          aria-label="Delete ticket"
        >
          ✕
        </button>
      </div>

      <h3 style={styles.subject}>{ticket.subject}</h3>
      <p style={styles.description}>{ticket.description}</p>

      <div style={styles.cardFooter}>
        <span style={styles.date}>🕐 {date}</span>
        <span style={styles.id}>#{ticket._id.slice(-6)}</span>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  card: {
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    padding: '1.1rem 1.25rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.6rem',
    animation: 'fadeInUp 0.25s ease',
    transition: 'border-color 0.15s, transform 0.15s',
  },
  cardTop: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '0.5rem',
  },
  badges: {
    display: 'flex',
    gap: '0.4rem',
    flexWrap: 'wrap' as const,
  },
  badge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.3rem',
    padding: '0.2rem 0.6rem',
    borderRadius: 100,
    fontSize: '0.73rem',
    fontWeight: 700,
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: '50%',
    flexShrink: 0,
  },
  deleteBtn: {
    background: 'var(--red-dim)',
    color: 'var(--red)',
    border: '1px solid transparent',
    borderRadius: 'var(--radius-sm)',
    width: 28,
    height: 28,
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: 700,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    transition: 'background 0.15s',
  },
  subject: {
    fontSize: '0.98rem',
    fontWeight: 700,
    color: 'var(--text)',
    lineHeight: 1.3,
  },
  description: {
    fontSize: '0.85rem',
    color: 'var(--text-dim)',
    lineHeight: 1.5,
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical' as const,
    overflow: 'hidden',
  },
  cardFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: '0.25rem',
  },
  date: {
    fontSize: '0.75rem',
    color: 'var(--text-muted)',
  },
  id: {
    fontSize: '0.73rem',
    color: 'var(--border-light)',
    fontFamily: 'DM Mono, monospace',
  },
};

export default TicketCard;
