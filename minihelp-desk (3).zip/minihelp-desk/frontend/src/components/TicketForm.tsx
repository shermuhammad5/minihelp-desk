import React, { useState } from 'react';
import type { Priority, Status } from '../types/ticket';

interface FormData {
  subject: string;
  description: string;
  priority: Priority;
  status: Status;
}

interface FormErrors {
  subject?: string;
  description?: string;
  priority?: string;
}

interface TicketFormProps {
  onSubmit: (data: FormData) => Promise<void>;
}

const TicketForm: React.FC<TicketFormProps> = ({ onSubmit }) => {
  const [form, setForm] = useState<FormData>({
    subject: '',
    description: '',
    priority: 'Low',
    status: 'Open',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSaving, setIsSaving] = useState(false); // GROUP 12: Disable Submit While Saving

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.subject.trim()) newErrors.subject = 'Subject is required';
    else if (form.subject.trim().length < 3) newErrors.subject = 'Subject must be at least 3 characters';
    else if (form.subject.trim().length > 100) newErrors.subject = 'Subject cannot exceed 100 characters';

    if (!form.description.trim()) newErrors.description = 'Description is required';
    else if (form.description.trim().length < 10) newErrors.description = 'Description must be at least 10 characters';

    if (!form.priority) newErrors.priority = 'Priority is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSaving(true); // GROUP 12: disable button
    try {
      await onSubmit(form);
      setForm({ subject: '', description: '', priority: 'Low', status: 'Open' });
      setErrors({});
    } finally {
      setIsSaving(false); // GROUP 12: re-enable button
    }
  };

  return (
    <form onSubmit={handleSubmit} style={styles.form} noValidate>
      <div style={styles.formHeader}>
        <span style={styles.formIcon}>＋</span>
        <h2 style={styles.formTitle}>New Ticket</h2>
      </div>

      <div style={styles.field}>
        <label style={styles.label}>Subject</label>
        <input
          name="subject"
          value={form.subject}
          onChange={handleChange}
          placeholder="e.g. Printer not working on 2nd floor"
          style={{ ...styles.input, ...(errors.subject ? styles.inputError : {}) }}
          disabled={isSaving}
        />
        {errors.subject && <span style={styles.errorMsg}>{errors.subject}</span>}
      </div>

      <div style={styles.field}>
        <label style={styles.label}>Description</label>
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Describe the issue in detail..."
          rows={3}
          style={{ ...styles.input, ...styles.textarea, ...(errors.description ? styles.inputError : {}) }}
          disabled={isSaving}
        />
        {errors.description && <span style={styles.errorMsg}>{errors.description}</span>}
      </div>

      <div style={styles.row}>
        <div style={{ ...styles.field, flex: 1 }}>
          <label style={styles.label}>Priority</label>
          <select
            name="priority"
            value={form.priority}
            onChange={handleChange}
            style={{ ...styles.input, ...styles.select }}
            disabled={isSaving}
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          {errors.priority && <span style={styles.errorMsg}>{errors.priority}</span>}
        </div>

        <div style={{ ...styles.field, flex: 1 }}>
          <label style={styles.label}>Status</label>
          <select
            name="status"
            value={form.status}
            onChange={handleChange}
            style={{ ...styles.input, ...styles.select }}
            disabled={isSaving}
          >
            <option value="Open">Open</option>
            <option value="In Progress">In Progress</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>

      {/* GROUP 12: Button disabled + text changes while saving */}
      <button type="submit" disabled={isSaving} style={{ ...styles.submitBtn, ...(isSaving ? styles.submitBtnDisabled : {}) }}>
        {isSaving ? (
          <>
            <span style={styles.spinner} />
            Saving...
          </>
        ) : (
          'Create Ticket'
        )}
      </button>
    </form>
  );
};

const styles: Record<string, React.CSSProperties> = {
  form: {
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    padding: '1.5rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  formHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    marginBottom: '0.25rem',
  },
  formIcon: {
    width: 32,
    height: 32,
    background: 'var(--accent-dim)',
    color: 'var(--accent)',
    borderRadius: '6px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '1.1rem',
    fontWeight: 700,
  } as React.CSSProperties,
  formTitle: {
    fontSize: '1.1rem',
    fontWeight: 700,
    color: 'var(--text)',
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.35rem',
  },
  label: {
    fontSize: '0.78rem',
    fontWeight: 600,
    color: 'var(--text-dim)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.06em',
  },
  input: {
    background: 'var(--surface2)',
    border: '1px solid var(--border-light)',
    borderRadius: 'var(--radius-sm)',
    color: 'var(--text)',
    padding: '0.6rem 0.85rem',
    fontSize: '0.9rem',
    fontFamily: 'Syne, sans-serif',
    outline: 'none',
    transition: 'border-color 0.15s',
    width: '100%',
  },
  inputError: {
    borderColor: 'var(--red)',
  },
  textarea: {
    resize: 'vertical' as const,
    minHeight: 80,
  },
  select: {
    cursor: 'pointer',
    appearance: 'none' as const,
  },
  errorMsg: {
    fontSize: '0.78rem',
    color: 'var(--red)',
  },
  row: {
    display: 'flex',
    gap: '0.75rem',
  },
  submitBtn: {
    background: 'var(--accent)',
    color: '#fff',
    border: 'none',
    borderRadius: 'var(--radius-sm)',
    padding: '0.7rem 1.5rem',
    fontSize: '0.95rem',
    fontWeight: 700,
    fontFamily: 'Syne, sans-serif',
    cursor: 'pointer',
    transition: 'background 0.15s, opacity 0.15s',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.5rem',
    marginTop: '0.25rem',
  },
  submitBtnDisabled: {
    opacity: 0.6,
    cursor: 'not-allowed',
    background: 'var(--text-muted)',
  },
  spinner: {
    width: 16,
    height: 16,
    border: '2px solid rgba(255,255,255,0.3)',
    borderTopColor: '#fff',
    borderRadius: '50%',
    display: 'inline-block',
    animation: 'spin 0.7s linear infinite',
  },
};

export default TicketForm;
