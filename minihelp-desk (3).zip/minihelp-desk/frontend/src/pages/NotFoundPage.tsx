import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage: React.FC = () => (
  <div style={styles.page}>
    <div style={styles.content}>
      <span style={styles.code}>404</span>
      <h1 style={styles.title}>Page Not Found</h1>
      <p style={styles.message}>The page you're looking for doesn't exist.</p>
      <Link to="/" style={styles.link}>← Back to Tickets</Link>
    </div>
  </div>
);

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'var(--bg)',
  },
  content: {
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '0.75rem',
  },
  code: {
    fontSize: '6rem',
    fontWeight: 800,
    color: 'var(--border-light)',
    lineHeight: 1,
  },
  title: {
    fontSize: '1.5rem',
    fontWeight: 800,
    color: 'var(--text)',
  },
  message: {
    color: 'var(--text-muted)',
    fontSize: '0.9rem',
  },
  link: {
    marginTop: '0.5rem',
    color: 'var(--accent)',
    textDecoration: 'none',
    fontWeight: 700,
    fontSize: '0.9rem',
  },
};

export default NotFoundPage;
