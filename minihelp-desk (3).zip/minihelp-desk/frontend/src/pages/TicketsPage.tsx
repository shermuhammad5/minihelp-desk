import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import type { Ticket } from '../types/ticket';
import { ticketApi } from '../api/ticketApi';
import TicketForm from '../components/TicketForm';
import TicketCard from '../components/TicketCard';
import ConfirmModal from '../components/ConfirmModal';

const TicketsPage: React.FC = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [isClearing, setIsClearing] = useState(false);

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ticketApi.getAll();
      setTickets(res.data || []);
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Failed to fetch tickets. Is the backend running?';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchTickets(); }, [fetchTickets]);

  const handleCreate = async (data: Omit<Ticket, '_id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const res = await ticketApi.create(data);
      if (res.success && res.data) {
        setTickets(prev => [res.data!, ...prev]);
        toast.success('Ticket created successfully!');
      }
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Failed to create ticket';
      toast.error(msg);
      throw err; // re-throw so form re-enables button
    }
  };

  const handleDeleteOne = async (id: string) => {
    setDeleteConfirm(id);
  };

  const confirmDeleteOne = async () => {
    if (!deleteConfirm) return;
    try {
      await ticketApi.deleteOne(deleteConfirm);
      setTickets(prev => prev.filter(t => t._id !== deleteConfirm));
      toast.success('Ticket deleted');
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Failed to delete ticket';
      toast.error(msg);
    } finally {
      setDeleteConfirm(null);
    }
  };

  // GROUP 12: Clear All Items
  const handleClearAll = () => setShowClearConfirm(true);

  const confirmClearAll = async () => {
    setIsClearing(true);
    try {
      const res = await ticketApi.clearAll();
      setTickets([]);
      setShowClearConfirm(false);
      toast.success(res.message || 'All tickets cleared!');
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Failed to clear tickets';
      toast.error(msg);
    } finally {
      setIsClearing(false);
    }
  };

  const openCount = tickets.filter(t => t.status === 'Open').length;
  const inProgressCount = tickets.filter(t => t.status === 'In Progress').length;
  const highCount = tickets.filter(t => t.priority === 'High').length;

  return (
    <div style={styles.page}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>🎫</span>
            <div>
              <h1 style={styles.headerTitle}>MiniHelpDesk</h1>
              <p style={styles.headerSub}>Ticket Management System</p>
            </div>
          </div>
        </div>
        <div style={styles.headerRight}>
          <span style={styles.groupBadge}>Group 12 · BSCS-VIB</span>
        </div>
      </header>

      {/* Stats Bar */}
      <div style={styles.statsBar}>
        <div style={styles.stat}>
          <span style={styles.statNumber}>{tickets.length}</span>
          <span style={styles.statLabel}>Total</span>
        </div>
        <div style={styles.statDivider} />
        <div style={styles.stat}>
          <span style={{ ...styles.statNumber, color: 'var(--accent)' }}>{openCount}</span>
          <span style={styles.statLabel}>Open</span>
        </div>
        <div style={styles.statDivider} />
        <div style={styles.stat}>
          <span style={{ ...styles.statNumber, color: 'var(--orange)' }}>{inProgressCount}</span>
          <span style={styles.statLabel}>In Progress</span>
        </div>
        <div style={styles.statDivider} />
        <div style={styles.stat}>
          <span style={{ ...styles.statNumber, color: 'var(--red)' }}>{highCount}</span>
          <span style={styles.statLabel}>High Priority</span>
        </div>
      </div>

      <div style={styles.layout}>
        {/* Sidebar: Create Form */}
        <aside style={styles.sidebar}>
          <TicketForm onSubmit={handleCreate} />
        </aside>

        {/* Main: Ticket List */}
        <main style={styles.main}>
          <div style={styles.listHeader}>
            <h2 style={styles.listTitle}>
              All Tickets
              <span style={styles.countBadge}>{tickets.length}</span>
            </h2>

            {/* GROUP 12: Clear All button */}
            {tickets.length > 0 && (
              <button
                onClick={handleClearAll}
                disabled={isClearing}
                style={styles.clearAllBtn}
                title="Delete all tickets"
              >
                🗑 Clear All
              </button>
            )}
          </div>

          {/* States */}
          {loading && (
            <div style={styles.centerState}>
              <div style={styles.loadingSpinner} />
              <p style={styles.stateText}>Loading tickets...</p>
            </div>
          )}

          {error && !loading && (
            <div style={styles.errorState}>
              <span style={styles.errorIcon}>⚡</span>
              <p style={styles.errorTitle}>Connection Error</p>
              <p style={styles.errorText}>{error}</p>
              <button onClick={fetchTickets} style={styles.retryBtn}>Retry</button>
            </div>
          )}

          {!loading && !error && tickets.length === 0 && (
            <div style={styles.emptyState}>
              <span style={styles.emptyIcon}>📭</span>
              <p style={styles.emptyTitle}>No tickets yet</p>
              <p style={styles.emptyText}>Create your first ticket using the form on the left.</p>
            </div>
          )}

          {!loading && !error && tickets.length > 0 && (
            <div style={styles.ticketGrid}>
              {tickets.map(ticket => (
                <TicketCard key={ticket._id} ticket={ticket} onDelete={handleDeleteOne} />
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Confirm Delete One */}
      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Ticket"
        message="Are you sure you want to delete this ticket? This action cannot be undone."
        confirmText="Delete"
        onConfirm={confirmDeleteOne}
        onCancel={() => setDeleteConfirm(null)}
        danger
      />

      {/* GROUP 12: Confirm Clear All Modal */}
      <ConfirmModal
        isOpen={showClearConfirm}
        title="Clear All Tickets"
        message={`This will permanently delete all ${tickets.length} ticket(s). This action cannot be undone.`}
        confirmText={isClearing ? 'Clearing...' : 'Yes, Clear All'}
        onConfirm={confirmClearAll}
        onCancel={() => !isClearing && setShowClearConfirm(false)}
        danger
      />
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: 'var(--bg)',
    display: 'flex',
    flexDirection: 'column',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '1.1rem 2rem',
    borderBottom: '1px solid var(--border)',
    background: 'var(--surface)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  headerLeft: { display: 'flex', alignItems: 'center' },
  logo: { display: 'flex', alignItems: 'center', gap: '0.75rem' },
  logoIcon: {
    fontSize: '1.6rem',
    width: 42,
    height: 42,
    background: 'var(--accent-dim)',
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  } as React.CSSProperties,
  headerTitle: { fontSize: '1.15rem', fontWeight: 800, color: 'var(--text)' },
  headerSub: { fontSize: '0.75rem', color: 'var(--text-muted)' },
  headerRight: {},
  groupBadge: {
    fontSize: '0.75rem',
    padding: '0.3rem 0.75rem',
    background: 'var(--accent-dim)',
    color: 'var(--accent)',
    borderRadius: 100,
    fontWeight: 700,
    letterSpacing: '0.04em',
  },
  statsBar: {
    display: 'flex',
    alignItems: 'center',
    gap: '0',
    padding: '0.8rem 2rem',
    background: 'var(--surface)',
    borderBottom: '1px solid var(--border)',
  },
  stat: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '0 1.5rem',
    gap: '0.1rem',
  },
  statNumber: {
    fontSize: '1.3rem',
    fontWeight: 800,
    color: 'var(--text)',
    lineHeight: 1,
  },
  statLabel: {
    fontSize: '0.7rem',
    color: 'var(--text-muted)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.06em',
    fontWeight: 600,
  },
  statDivider: {
    width: 1,
    height: 32,
    background: 'var(--border)',
  },
  layout: {
    display: 'flex',
    gap: '1.5rem',
    padding: '1.5rem 2rem',
    flex: 1,
    alignItems: 'flex-start',
    maxWidth: 1200,
    width: '100%',
    margin: '0 auto',
  },
  sidebar: {
    width: 320,
    flexShrink: 0,
    position: 'sticky',
    top: 80,
  },
  main: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    minWidth: 0,
  },
  listHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  listTitle: {
    fontSize: '1.1rem',
    fontWeight: 800,
    color: 'var(--text)',
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
  },
  countBadge: {
    fontSize: '0.75rem',
    padding: '0.15rem 0.55rem',
    background: 'var(--surface2)',
    border: '1px solid var(--border-light)',
    borderRadius: 100,
    color: 'var(--text-dim)',
    fontWeight: 600,
  },
  clearAllBtn: {
    background: 'var(--red-dim)',
    color: 'var(--red)',
    border: '1px solid rgba(240,82,82,0.25)',
    borderRadius: 'var(--radius-sm)',
    padding: '0.45rem 0.9rem',
    fontSize: '0.82rem',
    fontWeight: 700,
    cursor: 'pointer',
    fontFamily: 'Syne, sans-serif',
    transition: 'background 0.15s',
    display: 'flex',
    alignItems: 'center',
    gap: '0.35rem',
  },
  ticketGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '0.85rem',
  },
  centerState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '4rem 2rem',
  },
  loadingSpinner: {
    width: 36,
    height: 36,
    border: '3px solid var(--border-light)',
    borderTopColor: 'var(--accent)',
    borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
  },
  stateText: { color: 'var(--text-muted)', fontSize: '0.9rem' },
  errorState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '0.5rem',
    padding: '3rem 2rem',
    background: 'var(--red-dim)',
    border: '1px solid rgba(240,82,82,0.2)',
    borderRadius: 'var(--radius)',
    textAlign: 'center',
  },
  errorIcon: { fontSize: '2rem' },
  errorTitle: { fontWeight: 800, color: 'var(--red)', fontSize: '1rem' },
  errorText: { color: 'var(--text-dim)', fontSize: '0.85rem', maxWidth: 320 },
  retryBtn: {
    marginTop: '0.5rem',
    padding: '0.5rem 1.25rem',
    background: 'var(--red)',
    color: '#fff',
    border: 'none',
    borderRadius: 'var(--radius-sm)',
    fontFamily: 'Syne, sans-serif',
    fontWeight: 700,
    cursor: 'pointer',
    fontSize: '0.85rem',
  },
  emptyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '0.5rem',
    padding: '4rem 2rem',
    textAlign: 'center',
    border: '1.5px dashed var(--border-light)',
    borderRadius: 'var(--radius)',
  },
  emptyIcon: { fontSize: '2.5rem', marginBottom: '0.25rem' },
  emptyTitle: { fontWeight: 800, fontSize: '1rem', color: 'var(--text)' },
  emptyText: { color: 'var(--text-muted)', fontSize: '0.85rem' },
};

export default TicketsPage;
